import isValidEmail from '../src/app/email';


// Testfall 1: om e-post korrekt får vi valid 

describe('Email Validation True or False', () => {
    it('Valid Email', () => {
        expect(isValidEmail('jonaton@gmail.com')).toBe(true); // Får vi true
    });

    // Testfall 2: om e-post inte korrekt får vi invalid 
    it('Invalid Email', () => {
        expect(isValidEmail('jonaton@gmail')).toBe(false); // Får vi false
    });


    // Testfall 3: om e-post inte korrekt får vi invalid 
    it('Invalid Email', () => {
        expect(isValidEmail('jonaton.com')).toBe(false); // Får vi false
    });
});


