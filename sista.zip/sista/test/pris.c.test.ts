import roundPrice from '../src/app/pris.c';

describe('roundPrice', () => {
    expect(roundPrice(-15.67, 'NOK %PRICE%')).toBe('15.67 NOK');

    it('should use specified currency pattern even when not rounding', () => {
        expect(roundPrice(42, 'NOK %PRICE%')).toBe('42.00 NOK');
    });

    it('should use custom pattern for formatting', () => {
        expect(roundPrice(232.10542, '%PRICE% kr')).toBe('232.11 kr');
        expect(roundPrice(14, '$%PRICE%')).toBe('$14.00');
        expect(roundPrice(1024.2048, 'USD %PRICE%')).toBe('USD 1024.20 SEK');
    });
});
