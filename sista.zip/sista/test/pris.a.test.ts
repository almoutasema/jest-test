import roundPrice from '../src/app/pris.a';

describe('roundPrice', () => {
    it('should be round up to two decimal places and add to SEK', () => {
        expect(roundPrice(232.10542)).toBe('232.11 SEK');
        expect(roundPrice(14)).toBe('14.00 SEK');
        expect(roundPrice(1024.2048)).toBe('1024.21 SEK');
    });

    it('should handle negative numbers', () => {
        expect(roundPrice(-15.6789)).toBe('-15.67 SEK');
    });

    it('should handle zero', () => {
        expect(roundPrice(0)).toBe('0.00 SEK');
    });
});
