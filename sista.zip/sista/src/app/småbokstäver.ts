// src/isLowerCase.ts
const isLowerCase = (input: string): boolean => {
    return /^[a-z]+$/.test(input);
};

export default isLowerCase;
