const roundPrice = (price: number, pattern: string = '%PRICE% SEK'): string => {
    const roundedPrice = Math.ceil(price * 100) / 100;
    return pattern.replace('%PRICE%', roundedPrice.toFixed(2));
};

export default roundPrice;
