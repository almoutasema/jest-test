function Validatezipcode(zip: string): boolean {
    const zipRegex = /^\d{5}$/;
    return zipRegex.test(zip);
}

export default Validatezipcode;
