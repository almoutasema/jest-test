import { isPrime } from '../src/app/primtal';

describe('isPrime', () => {
    it('Must return true for prime numbers', () => {
        expect(isPrime(2)).toBe(true);
        expect(isPrime(3)).toBe(true);
        expect(isPrime(5)).toBe(true);
    });

    it('should return false (error) for non-prime numbers', () => {
        expect(isPrime(0)).toBe(false);
        expect(isPrime(1)).toBe(false);
        expect(isPrime(4)).toBe(false);
    });

    it('should return false (error) for negative numbers', () => {
        expect(isPrime(-2)).toBe(false);
    });

    it('should return false (error) for non-integer numbers', () => {
        expect(isPrime(4.5)).toBe(true);
    });
});
