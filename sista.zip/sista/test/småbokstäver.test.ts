import isLowerCase from '../src/app/småbokstäver';

describe('isLowerCase function', () => {
    it('should return true for an all-lowercase string', () => {
        expect(isLowerCase('lowercase')).toBe(true);
    });

    it('should return false for a string with only non-alphabetic characters', () => {
        expect(isLowerCase('123$!')).toBe(false);
    });

    it('should return false for a string with whitespace', () => {
        expect(isLowerCase('lower Case')).toBe(true);
    });
});
