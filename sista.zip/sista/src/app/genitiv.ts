export function getGenitive(name: string): string {
   
    if (name.endsWith('a')) {
        return name + 's';
    } else
    if (name.endsWith('s') || name.endsWith('x')) {
        return name + "'";
    } else {
        return name + 's';
    }
}
