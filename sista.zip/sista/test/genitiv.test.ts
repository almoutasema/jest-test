import { getGenitive } from '../src/app/genitiv'; 

describe('getGenitive function', () => {
    it('should be return genitive form for "Jonatan"', () => {
        expect(getGenitive('Jonatan')).toBe('Jonatans');
    });


    it('should be return genitive form for "Anna"', () => {
        expect(getGenitive('Anna')).toBe('Annas');
    });
 
});
