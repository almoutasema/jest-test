import Validatezipcode from '../src/app/validate';

//  Testfall 1: om validateZip korrekt får vi valid
it('validateZip must return true for a valid ZIP file', () => {
    expect(Validatezipcode('12345')).toBe(true);  // Får vi true
});

it('validateZip should return an error for a ZIP file that is less than 5 numbers long', () => {
    expect(Validatezipcode('1234')).toBe(false); // Får vi false
});

it('validateZip should return an error for a ZIP file containing more than 5 numbers', () => {
    expect(Validatezipcode('123456')).toBe(false);  // Får vi false
});

it('validateZip should return an error for non-digital compressed files', () => {
    expect(Validatezipcode('abcde')).toBe(false);   // Får vi false
});
