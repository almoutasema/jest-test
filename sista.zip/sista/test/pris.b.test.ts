import roundPrice from '../src/app/pris.b';

describe('roundPrice', () => {
    it('should be round up to two decimal places and add to SEK by default', () => {
        expect(roundPrice(232.10542)).toBe('232.11 SEK');
        expect(roundPrice(14)).toBe('14.00 SEK');
        expect(roundPrice(1024.2048)).toBe('1024.21 SEK');
    });

    it('should handle negative numbers and add specified currency', () => {
        expect(roundPrice(-15.6789, 'NOK')).toBe('-15.67 NOK');
        expect(roundPrice(-15.6789, 'USD')).toBe('-15.67 USD');
    });

    it('should handle zero and add specified currency', () => {
        expect(roundPrice(0, 'NOK')).toBe('0.00 NOK');
        expect(roundPrice(0, 'USD')).toBe('0.00 USD');
    });

    it('should add specified currency even when not rounding', () => {
        expect(roundPrice(42, 'NOK')).toBe('42.00 NOK');
    });
});
