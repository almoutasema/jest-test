import Heading from '../src/app/heading';


describe('Heading', () => {
    it('create h1 heading', () => {
        const result = Heading('Hello', 1);
        expect(result).toBe('<h1>Hello</h1>');
    });

    it('create h2 heading', () => {
        const result = Heading('Next level', 2);
        expect(result).toBe('<h2>Next level</h2>');
    });

    it('Throws an error for invalid level to heading', () => {
        expect(() => Heading('Invalid level', 7)).toThrow(
            'Heading level must be between 1 and 6'
        );
    });
});
